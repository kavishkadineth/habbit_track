# Wellness Tracker - Android App

## 📱 Project Overview

**Wellness Tracker** is a comprehensive Android application designed to promote personal wellness and manage daily health routines. This project was developed as part of the 2025 Lab Exam 03 for IT2010 – Mobile Application Development at SLIIT.

## 🎯 Features

### 1. Daily Habit Tracker
- ✅ Add, edit, and delete wellness habits (e.g., drink water, meditate, steps)
- 📊 Daily completion progress with progress bar and percentage
- 🎯 Customizable target counts for each habit
- 📂 Category-based habit organization
- 💾 Persistent storage using SharedPreferences

### 2. Mood Journal with Emoji Selector
- 😊 12 different mood emojis for emotional tracking
- 📝 Optional notes for each mood entry
- 📅 Timestamp tracking for all mood entries
- 📈 Mood trend visualization using MPAndroidChart
- 📤 Share mood entries functionality
- 📊 7-day mood trend chart with interactive visualization

### 3. Hydration Reminder System
- 💧 Daily water goal tracking with visual progress
- ⚡ Quick-add water buttons (100ml, 250ml, 500ml)
- 🔔 Configurable notification reminders (1, 2, 3-hour intervals)
- 📱 Notification-based reminders using AlarmManager
- 🌅 Automatic daily reset functionality
- 📊 Progress visualization with percentage completion

### 4. Advanced Features
- 📊 **MPAndroidChart Integration**: Interactive mood trend visualization
- 🔔 **Notification System**: Hydration reminders with custom intervals
- 💾 **Data Persistence**: SharedPreferences for offline data storage
- 🎨 **Material Design 3**: Modern, intuitive UI/UX
- 📱 **Responsive Design**: Portrait/landscape and phone/tablet support

## 🛠️ Technical Implementation

### Architecture
- **Language**: Kotlin
- **UI Framework**: Traditional Android Views (not Compose)
- **Navigation**: Android Navigation Component with Bottom Navigation
- **Data Storage**: SharedPreferences with Gson serialization
- **Charts**: MPAndroidChart library
- **Notifications**: AlarmManager with BroadcastReceivers

### Key Components

#### Activities & Fragments
- `MainActivity`: Entry point with bottom navigation
- `HabitTrackerFragment`: Habit management and tracking
- `MoodJournalFragment`: Mood logging and history
- `HydrationReminderFragment`: Water tracking and reminders
- `MoodChartDialogFragment`: Interactive mood trend chart

#### Data Models
- `Habit`: Represents a wellness habit with completion tracking
- `MoodEntry`: Represents a mood journal entry with emoji and notes
- `SharedPreferencesManager`: Utility class for data persistence

#### Utilities
- `HydrationReminderReceiver`: Handles hydration notification broadcasts
- `BootReceiver`: Restarts reminders after device reboot

### Dependencies
```kotlin
implementation 'androidx.core:core-ktx:1.17.0'
implementation 'androidx.fragment:fragment-ktx:1.8.5'
implementation 'androidx.navigation:navigation-fragment-ktx:2.8.5'
implementation 'androidx.navigation:navigation-ui-ktx:2.8.5'
implementation 'com.google.android.material:material:1.12.0'
implementation 'com.github.PhilJay:MPAndroidChart:3.1.0'
implementation 'com.google.code.gson:gson:2.10.1'
```

## 📁 Project Structure

```
app/
├── src/main/
│   ├── java/com/example/labexam03new/
│   │   ├── MainActivity.kt
│   │   ├── data/
│   │   │   └── SharedPreferencesManager.kt
│   │   ├── models/
│   │   │   ├── Habit.kt
│   │   │   └── MoodEntry.kt
│   │   ├── fragments/
│   │   │   ├── HabitTrackerFragment.kt
│   │   │   ├── MoodJournalFragment.kt
│   │   │   ├── HydrationReminderFragment.kt
│   │   │   └── MoodChartDialogFragment.kt
│   │   ├── adapters/
│   │   │   ├── HabitAdapter.kt
│   │   │   ├── EmojiAdapter.kt
│   │   │   └── MoodEntryAdapter.kt
│   │   └── utils/
│   │       ├── HydrationReminderReceiver.kt
│   │       └── BootReceiver.kt
│   ├── res/
│   │   ├── layout/
│   │   │   ├── activity_main.xml
│   │   │   ├── fragment_habit_tracker.xml
│   │   │   ├── fragment_mood_journal.xml
│   │   │   ├── fragment_hydration_reminder.xml
│   │   │   ├── item_habit.xml
│   │   │   ├── item_mood_entry.xml
│   │   │   ├── item_emoji.xml
│   │   │   ├── dialog_add_edit_habit.xml
│   │   │   └── dialog_mood_chart.xml
│   │   ├── navigation/
│   │   │   └── nav_graph.xml
│   │   ├── menu/
│   │   │   └── bottom_navigation_menu.xml
│   │   ├── drawable/
│   │   │   └── [various icon files]
│   │   ├── values/
│   │   │   ├── colors.xml
│   │   │   ├── strings.xml
│   │   │   └── themes.xml
│   │   └── xml/
│   │       ├── backup_rules.xml
│   │       └── data_extraction_rules.xml
│   └── AndroidManifest.xml
```

## 🚀 Getting Started

### Prerequisites
- Android Studio Hedgehog or later
- Android SDK 27+ (Android 8.1+)
- Kotlin 2.0.21+
- Gradle 8.12.3+

### Installation
1. Clone or download the project
2. Open in Android Studio
3. Sync project with Gradle files
4. Build and run on device/emulator

### First-Time Setup
**Authentication Flow:**
1. **First Launch**: App opens to Login/Signup screen
2. **Create Account**: 
   - Click "Sign Up" tab
   - Enter username (min 3 characters)
   - Enter email address
   - Enter password (min 6 characters)
   - Confirm password
   - Click "Sign Up"
3. **Login**: 
   - Enter your username and password
   - Click "Login"
4. **Logout**: 
   - Go to Profile tab
   - Scroll to "Account Settings"
   - Click "Logout" button
   - Confirm logout

**Note**: For first-time users without creating an account, the app will auto-login to allow exploration. Once you create an account and logout, you'll need to login again.

### Permissions
The app requires the following permissions:
- `POST_NOTIFICATIONS`: For hydration reminders
- `VIBRATE`: For notification vibrations
- `WAKE_LOCK`: For alarm management
- `RECEIVE_BOOT_COMPLETED`: For restarting reminders after reboot
- `USE_FULL_SCREEN_INTENT`: For full-screen notifications

## 🎨 Design Features

### Material Design 3
- Modern color scheme with wellness-focused palette
- Consistent typography and spacing
- Elevated cards with proper shadows
- Smooth animations and transitions

### Color Palette
- **Primary**: Green (#2E7D32) - Represents health and wellness
- **Secondary**: Light Green (#4CAF50) - Accent color
- **Accent**: Mint Green (#81C784) - Highlight color
- **Mood Colors**: Yellow (happy), Blue (sad), Gray (neutral)

### UI Components
- Bottom Navigation for easy access
- Floating Action Buttons for primary actions
- Progress Bars for visual feedback
- Material Cards for content organization
- Text Input Fields with proper validation

## 📊 Data Management

### SharedPreferences Storage
- **Habits**: List of user-defined wellness habits
- **Mood Entries**: Historical mood data with timestamps
- **Settings**: Reminder preferences and water goals
- **Daily Progress**: Current day's completion status

### Data Serialization
- Uses Gson for JSON serialization/deserialization
- Handles data migration and error recovery
- Maintains data integrity across app sessions

## 🔔 Notification System

### Hydration Reminders
- Configurable intervals (1, 2, 3 hours)
- Persistent notifications across app restarts
- Boot receiver for automatic restart
- Custom notification channel for Android 8.0+

### Notification Features
- Custom icons and colors
- Vibration patterns
- Action buttons for quick responses
- Dismissible notifications

## 📈 Chart Visualization

### Mood Trends Chart
- 7-day mood trend visualization
- Interactive line chart with touch support
- Average mood calculation per day
- Zoom and pan functionality
- Custom styling with app theme colors

## 🧪 Testing

### Manual Testing Checklist
- [ ] Add, edit, delete habits
- [ ] Mark habits as complete
- [ ] Log mood entries with emojis
- [ ] View mood history and charts
- [ ] Set hydration reminders
- [ ] Track water consumption
- [ ] Receive notification reminders
- [ ] Share mood entries
- [ ] App state persistence

### Device Testing
- Tested on various screen sizes
- Portrait and landscape orientations
- Different Android versions (8.1+)
- Various device manufacturers

## 🚀 Future Enhancements

### Potential Improvements
- [ ] Database migration from SharedPreferences
- [ ] Cloud sync functionality
- [ ] Widget for home screen
- [ ] Sensor integration (accelerometer for shake detection)
- [ ] Social sharing features
- [ ] Achievement system
- [ ] Data export functionality
- [ ] Dark theme support
- [ ] Multiple language support

## 📝 Assignment Requirements Compliance

### ✅ Core Requirements Met
- **Daily Habit Tracker**: ✅ Complete with progress tracking
- **Mood Journal**: ✅ Emoji selector with history
- **Hydration Reminder**: ✅ Notification system with AlarmManager
- **Advanced Feature**: ✅ MPAndroidChart for mood trends

### ✅ Technical Requirements Met
- **Kotlin**: ✅ 100% Kotlin implementation
- **Activities/Fragments**: ✅ Fragment-based architecture
- **SharedPreferences**: ✅ No database, persistent storage
- **Intents**: ✅ Navigation and sharing functionality
- **Responsive UI**: ✅ Material Design 3 implementation
- **State Management**: ✅ Data persistence across restarts

### ✅ Design Requirements Met
- **Clean UI**: ✅ Material Design 3 components
- **Intuitive Navigation**: ✅ Bottom navigation
- **Material Colors**: ✅ Custom wellness-themed palette
- **Organized Structure**: ✅ Proper package organization

## 👨‍💻 Development Notes

### Code Quality
- Comprehensive comments for all key functions
- Proper error handling and validation
- Clean architecture with separation of concerns
- Consistent naming conventions
- Resource optimization

### Performance Considerations
- Efficient RecyclerView implementations
- Optimized chart rendering
- Minimal memory usage
- Fast SharedPreferences operations
- Background task management

## 📄 License

This project is developed for educational purposes as part of the SLIIT IT2010 Mobile Application Development course.

## 👥 Author

**Student**: [Your Name]  
**Course**: IT2010 – Mobile Application Development  
**Institution**: SLIIT  
**Year**: 2025

---

*This wellness tracker app demonstrates proficiency in Android development, Kotlin programming, Material Design implementation, and user experience design.*
