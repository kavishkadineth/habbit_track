# Wellness Tracker - Complete User Flow Guide

## 📋 User State Flow (Implemented)

| User State | Condition | App Restart Behavior |
|------------|-----------|---------------------|
| **Logged In** | `isLoggedIn = true` | → **Main App (direct)** ✅ |
| **Logged Out (has account)** | `hasAccount = true` but `isLoggedIn = false` | → **Login Screen** ✅ |
| **First Time (no account)** | `hasAccount = false` | → **Onboarding** ✅ |

---

## 🔄 Complete Flow Diagrams

### State 1: First-Time User (No Account)

```
┌─────────────────────────────────────────────────────────────┐
│ User installs app and launches for the first time          │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ OnboardingActivity (LAUNCHER)                               │
│ Check: isUserLoggedIn()? → NO                              │
│ Check: hasUserAccount()? → NO                              │
│ Check: isOnboardingCompleted()? → NO                       │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ ✅ Show Onboarding Screens (3 screens)                      │
│ - Track Your Habits                                          │
│ - Monitor Your Mood                                          │
│ - Stay Hydrated                                              │
└─────────────────────────────────────────────────────────────┘
                            ↓
                    [Get Started]
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ LoginActivity                                                │
│ User sees: Sign Up tab selected                             │
└─────────────────────────────────────────────────────────────┘
                            ↓
                  [User creates account]
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ Account created:                                             │
│ - user_account saved                                         │
│ - is_logged_in = true                                       │
│ - current_username saved                                     │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ ✅ MainActivity (Main App)                                   │
│ User can now use all features                               │
└─────────────────────────────────────────────────────────────┘
```

---

### State 2: Logged-In User Restarts App

```
┌─────────────────────────────────────────────────────────────┐
│ User closes app and reopens (still logged in)              │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ OnboardingActivity (LAUNCHER)                               │
│ Check: isUserLoggedIn()? → YES ✓                           │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ ✅ Navigate DIRECTLY to MainActivity                         │
│ Skip: Onboarding ❌                                          │
│ Skip: Login Screen ❌                                        │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ ✅ MainActivity (Main App)                                   │
│ User has immediate access to all features                   │
└─────────────────────────────────────────────────────────────┘
```

---

### State 3: User Logs Out

```
┌─────────────────────────────────────────────────────────────┐
│ User clicks Logout in Profile tab                           │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ Confirmation Dialog: "Are you sure you want to logout?"    │
└─────────────────────────────────────────────────────────────┘
                            ↓
                      [User confirms]
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ Logout action:                                              │
│ - is_logged_in = false                                      │
│ - current_username = ""                                     │
│ - user_account REMAINS (not deleted)                       │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ OnboardingActivity (LAUNCHER)                               │
│ Check: isUserLoggedIn()? → NO                              │
│ Check: hasUserAccount()? → YES ✓                           │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ ✅ Navigate to LoginActivity                                 │
│ Skip: Onboarding ❌ (user has account)                      │
└─────────────────────────────────────────────────────────────┘
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ LoginActivity                                                │
│ User sees: Login tab selected (account exists)             │
└─────────────────────────────────────────────────────────────┘
                            ↓
              [User enters credentials & logs in]
                            ↓
┌─────────────────────────────────────────────────────────────┐
│ ✅ MainActivity (Main App)                                   │
│ User is logged back in                                      │
└─────────────────────────────────────────────────────────────┘
```

---

## 🎯 Decision Logic in OnboardingActivity

```kotlin
override fun onCreate(savedInstanceState: Bundle?) {
    // PRIORITY 1: Check if logged in
    if (isUserLoggedIn()) {
        navigateToMainApp()  // → MainActivity
        return
    }
    
    // PRIORITY 2: Check if account exists or onboarding seen
    if (isOnboardingCompleted() || hasUserAccount()) {
        navigateToLogin()  // → LoginActivity
        return
    }
    
    // PRIORITY 3: First-time user
    setupOnboardingItems()  // Show onboarding
}
```

### Helper Functions:

1. **`isUserLoggedIn()`**
   - Checks: `SharedPreferences.getBoolean("is_logged_in", false)`
   - Returns: `true` if user is logged in

2. **`hasUserAccount()`**
   - Checks: `SharedPreferences.getString("user_account", null)`
   - Returns: `true` if account exists (not null)

3. **`isOnboardingCompleted()`**
   - Checks: `SharedPreferences.getBoolean("onboarding_completed", false)`
   - Returns: `true` if onboarding was completed

---

## 📊 SharedPreferences State Keys

| Key | Type | Purpose |
|-----|------|---------|
| `is_logged_in` | Boolean | Current login status |
| `user_account` | String (JSON) | Stored user account data |
| `current_username` | String | Currently logged-in username |
| `onboarding_completed` | Boolean | Whether onboarding was seen |

---

## 🧪 Testing Scenarios

### Test 1: Fresh Install
```
1. Uninstall app
2. Install and launch
Expected: Onboarding screens → Sign Up → Main App ✅
```

### Test 2: Restart While Logged In
```
1. Login to app
2. Close app completely (force stop or swipe away)
3. Relaunch app
Expected: Main App directly (no onboarding, no login) ✅
```

### Test 3: Logout and Restart
```
1. Login to app
2. Logout from Profile tab
Expected: Login screen (no onboarding) ✅
3. Close app
4. Relaunch app
Expected: Login screen (no onboarding) ✅
```

### Test 4: Login, Restart, Logout, Restart
```
1. Login to app → Main App ✅
2. Restart app → Main App directly ✅
3. Logout → Login screen ✅
4. Restart app → Login screen ✅
5. Login again → Main App ✅
```

### Test 5: Skip Onboarding
```
1. Fresh install
2. See onboarding
3. Click "Skip"
Expected: Login screen (onboarding_completed saved) ✅
4. Restart app
Expected: Login screen (onboarding skipped) ✅
```

---

## 🔐 Login State Management

### When `is_logged_in = true`:
- Set by: LoginActivity after successful login/signup
- Set by: MainActivity for first-time users without account
- Cleared by: ProfileFragment logout function

### When `is_logged_in = false`:
- User is logged out
- Must login to access MainActivity
- OnboardingActivity redirects to LoginActivity (if account exists)

---

## ✅ Current Implementation Status

| Feature | Status |
|---------|--------|
| First-time onboarding | ✅ Implemented |
| Skip onboarding | ✅ Implemented |
| Persistent login | ✅ Implemented |
| Logout functionality | ✅ Implemented |
| Direct app access (logged in) | ✅ Implemented |
| Skip onboarding after account creation | ✅ Implemented |
| Smart navigation | ✅ Implemented |

---

## 🚀 User Experience Summary

**First-Time User:**
1. Onboarding (3 screens) → Sign Up → Main App
2. Future restarts: Main App directly (while logged in)

**Returning User (Logged In):**
1. App restart → Main App directly (instant access!)

**Logged Out User:**
1. Logout → Login Screen
2. App restart → Login Screen (no onboarding)
3. Login → Main App

---

## 📝 Notes

- **Onboarding is ONLY shown once** to first-time users
- **Login state persists** across app restarts
- **Account data is preserved** even after logout
- **Reset Account button** available for testing in LoginActivity
- **Smart navigation** based on user state

---

**All three user states are correctly implemented and working as specified!** ✅


