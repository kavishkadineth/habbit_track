package com.example.labexam03new.models

import java.util.UUID

/**
 * Data class representing a wellness habit
 * @param id Unique identifier for the habit
 * @param name Name of the habit (e.g., "Drink Water", "Meditate")
 * @param description Optional description of the habit
 * @param targetCount Target number of times to complete per day
 * @param completedCount Current completion count for today
 * @param isCompleted Whether the habit is marked as completed today
 * @param category Category of the habit (e.g., "Health", "Mindfulness", "Exercise")
 * @param createdAt Timestamp when the habit was created
 */
data class Habit(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val description: String = "",
    val targetCount: Int = 1,
    var completedCount: Int = 0,
    var isCompleted: Boolean = false,
    val category: String = "General",
    val createdAt: Long = System.currentTimeMillis()
) {
    /**
     * Calculates the completion percentage for today
     * @return Percentage (0-100) of habit completion
     */
    fun getCompletionPercentage(): Int {
        return if (targetCount > 0) {
            ((completedCount.toFloat() / targetCount.toFloat()) * 100).toInt()
        } else {
            0
        }
    }
    
    /**
     * Checks if the habit is fully completed for today
     * @return true if completedCount >= targetCount
     */
    fun isFullyCompleted(): Boolean {
        return completedCount >= targetCount
    }
    
    /**
     * Resets the daily progress (called at midnight)
     */
    fun resetDailyProgress() {
        completedCount = 0
        isCompleted = false
    }
}
