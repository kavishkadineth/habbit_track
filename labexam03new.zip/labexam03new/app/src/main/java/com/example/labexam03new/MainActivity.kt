package com.example.labexam03new

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.example.labexam03new.databinding.ActivityMainBinding
import com.example.labexam03new.data.SharedPreferencesManager
import com.example.labexam03new.utils.SampleDataGenerator

/**
 * MainActivity - Entry point of the Wellness App
 * Features:
 * - Bottom navigation between Habit Tracker, Mood Journal, and Hydration Reminder
 * - Notification permission handling
 * - SharedPreferences initialization
 */
class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    private lateinit var prefsManager: SharedPreferencesManager
    
    // Notification permission launcher
    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            // Permission granted, can now send notifications
            setupHydrationReminders()
        } else {
            // Permission denied, show a message or disable notification features
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Initialize SharedPreferences manager
        prefsManager = SharedPreferencesManager(this)
        
        // Check if user is logged in - only check if account exists
        if (prefsManager.hasAccount() && !prefsManager.isLoggedIn()) {
            navigateToLogin()
            return
        }
        
        // For first-time users without account, auto-login
        if (!prefsManager.hasAccount()) {
            prefsManager.setLoggedIn(true)
        }
        
        // Initialize view binding
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        // Setup navigation
        setupBottomNavigation()
        
        // Request notification permission if not granted
        checkNotificationPermission()
        
        // Initialize with sample data if no data exists (for testing)
        initializeSampleDataIfNeeded()
    }
    
    /**
     * Sets up the bottom navigation with NavController
     */
    private fun setupBottomNavigation() {
        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        val navController = navHostFragment.navController
        
        // Connect bottom navigation with NavController
        binding.bottomNavigation.setupWithNavController(navController)
    }
    
    /**
     * Checks and requests notification permission if needed
     */
    private fun checkNotificationPermission() {
        when {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED -> {
                // Permission already granted
                setupHydrationReminders()
            }
            else -> {
                // Request permission
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }
    
    /**
     * Sets up hydration reminders if notifications are enabled
     */
    private fun setupHydrationReminders() {
        if (prefsManager.isHydrationReminderEnabled()) {
            // This will be implemented in the HydrationReminderFragment
        }
    }
    
    /**
     * Initializes sample data if no data exists (for testing purposes)
     */
    private fun initializeSampleDataIfNeeded() {
        val habits = prefsManager.getHabits()
        val moodEntries = prefsManager.getMoodEntries()
        
        // If no data exists, initialize with sample data
        if (habits.isEmpty() && moodEntries.isEmpty()) {
            SampleDataGenerator.initializeWithSampleData(prefsManager)
        }
    }
    
    /**
     * Navigates to login activity
     */
    private fun navigateToLogin() {
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
    
    /**
     * Provides access to SharedPreferences manager for fragments
     */
    fun getPrefsManager(): SharedPreferencesManager = prefsManager
}