package com.example.labexam03new.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.labexam03new.R
import com.example.labexam03new.adapters.EmojiAdapter
import com.example.labexam03new.adapters.MoodEntryAdapter
import com.example.labexam03new.data.SharedPreferencesManager
import com.example.labexam03new.databinding.FragmentMoodJournalBinding
import com.example.labexam03new.models.MoodEntry

/**
 * MoodJournalFragment - Manages mood tracking and journaling
 * Features:
 * - Emoji selector for mood logging
 * - Mood entry history with notes
 * - Mood trend visualization
 * - Share mood summary functionality
 */
class MoodJournalFragment : Fragment() {
    
    private var _binding: FragmentMoodJournalBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var prefsManager: SharedPreferencesManager
    private lateinit var emojiAdapter: EmojiAdapter
    private lateinit var moodEntryAdapter: MoodEntryAdapter
    private var moodEntries: MutableList<MoodEntry> = mutableListOf()
    private var selectedEmoji: String = ""
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentMoodJournalBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        // Initialize SharedPreferences manager
        prefsManager = (requireActivity() as com.example.labexam03new.MainActivity).getPrefsManager()
        
        setupEmojiSelector()
        setupMoodEntriesList()
        setupClickListeners()
        loadMoodEntries()
    }
    
    /**
     * Sets up the emoji selector RecyclerView
     */
    private fun setupEmojiSelector() {
        emojiAdapter = EmojiAdapter(
            emojis = MoodEntry.MOOD_EMOJIS,
            onEmojiClick = { emoji -> selectEmoji(emoji) }
        )
        
        binding.recyclerViewEmojiSelector.apply {
            layoutManager = GridLayoutManager(requireContext(), 6)
            adapter = emojiAdapter
        }
    }
    
    /**
     * Sets up the mood entries RecyclerView
     */
    private fun setupMoodEntriesList() {
        moodEntryAdapter = MoodEntryAdapter(
            moodEntries = moodEntries,
            onShareClick = { moodEntry -> shareMoodEntry(moodEntry) }
        )
        
        binding.recyclerViewMoodEntries.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = moodEntryAdapter
        }
    }
    
    /**
     * Sets up click listeners
     */
    private fun setupClickListeners() {
        binding.btnSaveMood.setOnClickListener {
            saveMoodEntry()
        }
        
        binding.btnViewChart.setOnClickListener {
            showMoodChart()
        }
    }
    
    /**
     * Loads mood entries from SharedPreferences
     */
    private fun loadMoodEntries() {
        moodEntries.clear()
        moodEntries.addAll(prefsManager.getMoodEntries().sortedByDescending { it.timestamp })
        moodEntryAdapter.notifyDataSetChanged()
    }
    
    /**
     * Handles emoji selection
     */
    private fun selectEmoji(emoji: String) {
        selectedEmoji = emoji
        emojiAdapter.setSelectedEmoji(emoji)
        emojiAdapter.notifyDataSetChanged()
    }
    
    /**
     * Saves a new mood entry
     */
    private fun saveMoodEntry() {
        if (selectedEmoji.isEmpty()) {
            Toast.makeText(requireContext(), "Please select a mood emoji", Toast.LENGTH_SHORT).show()
            return
        }
        
        val note = binding.etMoodNote.text.toString().trim()
        val moodLevel = MoodEntry.MOOD_LEVELS[selectedEmoji] ?: 5
        
        val moodEntry = MoodEntry(
            emoji = selectedEmoji,
            note = note,
            moodLevel = moodLevel
        )
        
        prefsManager.addMoodEntry(moodEntry)
        loadMoodEntries()
        
        // Clear form
        binding.etMoodNote.text?.clear()
        selectedEmoji = ""
        emojiAdapter.setSelectedEmoji("")
        emojiAdapter.notifyDataSetChanged()
        
        Toast.makeText(requireContext(), "Mood saved successfully!", Toast.LENGTH_SHORT).show()
    }
    
    /**
     * Shows mood trend chart
     */
    private fun showMoodChart() {
        // Navigate to chart fragment or show chart dialog
        val chartDialog = MoodChartDialogFragment()
        chartDialog.show(parentFragmentManager, "mood_chart")
    }
    
    /**
     * Shares a mood entry
     */
    private fun shareMoodEntry(moodEntry: MoodEntry) {
        val shareText = "My mood today: ${moodEntry.emoji} ${moodEntry.getMoodDescription()}\n" +
                if (moodEntry.note.isNotEmpty()) "Note: ${moodEntry.note}\n" else "" +
                "Time: ${moodEntry.getFormattedDateTime()}"
        
        val shareIntent = Intent().apply {
            action = Intent.ACTION_SEND
            putExtra(Intent.EXTRA_TEXT, shareText)
            type = "text/plain"
        }
        
        startActivity(Intent.createChooser(shareIntent, "Share Mood"))
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
