package com.example.labexam03new.models

/**
 * Data class representing a user profile
 * @param name User's full name
 * @param email User's email address
 * @param age User's age
 * @param weight User's weight in kg
 * @param height User's height in cm
 * @param gender User's gender
 * @param dailyWaterGoal Daily water intake goal in ml
 * @param dailyStepsGoal Daily steps goal
 * @param profileCreatedAt Timestamp when profile was created
 */
data class UserProfile(
    val name: String = "",
    val email: String = "",
    val age: Int = 0,
    val weight: Double = 0.0,
    val height: Double = 0.0,
    val gender: String = "",
    val dailyWaterGoal: Int = 2000,
    val dailyStepsGoal: Int = 10000,
    val profileCreatedAt: Long = System.currentTimeMillis()
) {
    /**
     * Checks if the profile is complete
     */
    fun isProfileComplete(): Boolean {
        return name.isNotEmpty() && email.isNotEmpty() && age > 0
    }
    
    /**
     * Calculates BMI (Body Mass Index)
     */
    fun calculateBMI(): Double {
        return if (height > 0 && weight > 0) {
            val heightInMeters = height / 100.0
            weight / (heightInMeters * heightInMeters)
        } else {
            0.0
        }
    }
    
    /**
     * Gets BMI category
     */
    fun getBMICategory(): String {
        val bmi = calculateBMI()
        return when {
            bmi < 18.5 -> "Underweight"
            bmi < 25.0 -> "Normal"
            bmi < 30.0 -> "Overweight"
            else -> "Obese"
        }
    }
    
    /**
     * Gets recommended daily water intake based on weight
     */
    fun getRecommendedWaterIntake(): Int {
        return if (weight > 0) {
            (weight * 35).toInt() // 35ml per kg of body weight
        } else {
            2000 // Default 2000ml
        }
    }
}
