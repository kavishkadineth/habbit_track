package com.example.labexam03new.data

import android.content.Context
import android.content.SharedPreferences
import com.example.labexam03new.models.Habit
import com.example.labexam03new.models.MoodEntry
import com.example.labexam03new.models.UserProfile
import com.example.labexam03new.models.UserAccount
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken

/**
 * SharedPreferences utility class for managing app data persistence
 * Handles habits, mood entries, and settings storage
 */
class SharedPreferencesManager(context: Context) {
    
    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val gson = Gson()
    
    companion object {
        private const val PREFS_NAME = "wellness_app_prefs"
        
        // Keys for different data types
        private const val KEY_HABITS = "habits"
        private const val KEY_MOOD_ENTRIES = "mood_entries"
        private const val KEY_HYDRATION_REMINDER_ENABLED = "hydration_reminder_enabled"
        private const val KEY_HYDRATION_INTERVAL = "hydration_interval_minutes"
        private const val KEY_DAILY_WATER_GOAL = "daily_water_goal"
        private const val KEY_WATER_CONSUMED = "water_consumed_today"
        private const val KEY_LAST_WATER_RESET = "last_water_reset_date"
        private const val KEY_USER_PROFILE = "user_profile"
        private const val KEY_USER_ACCOUNT = "user_account"
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
        private const val KEY_CURRENT_USERNAME = "current_username"
    }
    
    // Habit Management
    fun saveHabits(habits: List<Habit>) {
        val json = gson.toJson(habits)
        prefs.edit().putString(KEY_HABITS, json).apply()
    }
    
    fun getHabits(): List<Habit> {
        val json = prefs.getString(KEY_HABITS, null)
        return if (json != null) {
            try {
                val type = object : TypeToken<List<Habit>>() {}.type
                gson.fromJson(json, type) ?: emptyList()
            } catch (e: Exception) {
                emptyList()
            }
        } else {
            emptyList()
        }
    }
    
    fun addHabit(habit: Habit) {
        val habits = getHabits().toMutableList()
        habits.add(habit)
        saveHabits(habits)
    }
    
    fun updateHabit(habit: Habit) {
        val habits = getHabits().toMutableList()
        val index = habits.indexOfFirst { it.id == habit.id }
        if (index != -1) {
            habits[index] = habit
            saveHabits(habits)
        }
    }
    
    fun deleteHabit(habitId: String) {
        val habits = getHabits().toMutableList()
        habits.removeAll { it.id == habitId }
        saveHabits(habits)
    }
    
    // Mood Entry Management
    fun saveMoodEntries(moodEntries: List<MoodEntry>) {
        val json = gson.toJson(moodEntries)
        prefs.edit().putString(KEY_MOOD_ENTRIES, json).apply()
    }
    
    fun getMoodEntries(): List<MoodEntry> {
        val json = prefs.getString(KEY_MOOD_ENTRIES, null)
        return if (json != null) {
            try {
                val type = object : TypeToken<List<MoodEntry>>() {}.type
                gson.fromJson(json, type) ?: emptyList()
            } catch (e: Exception) {
                emptyList()
            }
        } else {
            emptyList()
        }
    }
    
    fun addMoodEntry(moodEntry: MoodEntry) {
        val moodEntries = getMoodEntries().toMutableList()
        moodEntries.add(moodEntry)
        saveMoodEntries(moodEntries)
    }
    
    // Hydration Settings
    fun setHydrationReminderEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_HYDRATION_REMINDER_ENABLED, enabled).apply()
    }
    
    fun isHydrationReminderEnabled(): Boolean {
        return prefs.getBoolean(KEY_HYDRATION_REMINDER_ENABLED, false)
    }
    
    fun setHydrationInterval(minutes: Int) {
        prefs.edit().putInt(KEY_HYDRATION_INTERVAL, minutes).apply()
    }
    
    fun getHydrationInterval(): Int {
        return prefs.getInt(KEY_HYDRATION_INTERVAL, 120) // Default 2 hours
    }
    
    fun setDailyWaterGoal(goal: Int) {
        prefs.edit().putInt(KEY_DAILY_WATER_GOAL, goal).apply()
    }
    
    fun getDailyWaterGoal(): Int {
        return prefs.getInt(KEY_DAILY_WATER_GOAL, 2000) // Default 2000ml
    }
    
    fun setWaterConsumed(amount: Int) {
        prefs.edit().putInt(KEY_WATER_CONSUMED, amount).apply()
    }
    
    fun getWaterConsumed(): Int {
        return prefs.getInt(KEY_WATER_CONSUMED, 0)
    }
    
    fun setLastWaterResetDate(date: String) {
        prefs.edit().putString(KEY_LAST_WATER_RESET, date).apply()
    }
    
    fun getLastWaterResetDate(): String? {
        return prefs.getString(KEY_LAST_WATER_RESET, null)
    }
    
    // Utility methods
    fun clearAllData() {
        prefs.edit().clear().apply()
    }
    
    fun resetDailyData() {
        setWaterConsumed(0)
        setLastWaterResetDate(getCurrentDate())
    }
    
    private fun getCurrentDate(): String {
        val calendar = java.util.Calendar.getInstance()
        val year = calendar.get(java.util.Calendar.YEAR)
        val month = calendar.get(java.util.Calendar.MONTH) + 1
        val day = calendar.get(java.util.Calendar.DAY_OF_MONTH)
        return "$year-$month-$day"
    }
    
    // User Profile Management
    fun saveUserProfile(profile: UserProfile) {
        val json = gson.toJson(profile)
        prefs.edit().putString(KEY_USER_PROFILE, json).apply()
    }
    
    fun getUserProfile(): UserProfile? {
        val json = prefs.getString(KEY_USER_PROFILE, null)
        return if (json != null) {
            try {
                gson.fromJson(json, UserProfile::class.java)
            } catch (e: Exception) {
                null
            }
        } else {
            null
        }
    }
    
    fun hasUserProfile(): Boolean {
        return getUserProfile() != null
    }
    
    // Authentication Management
    fun saveUserAccount(account: UserAccount) {
        val json = gson.toJson(account)
        prefs.edit().putString(KEY_USER_ACCOUNT, json).apply()
    }
    
    fun getUserAccount(): UserAccount? {
        val json = prefs.getString(KEY_USER_ACCOUNT, null)
        return if (json != null) {
            try {
                gson.fromJson(json, UserAccount::class.java)
            } catch (e: Exception) {
                null
            }
        } else {
            null
        }
    }
    
    fun setLoggedIn(isLoggedIn: Boolean) {
        prefs.edit().putBoolean(KEY_IS_LOGGED_IN, isLoggedIn).apply()
    }
    
    fun isLoggedIn(): Boolean {
        return prefs.getBoolean(KEY_IS_LOGGED_IN, false)
    }
    
    fun setCurrentUsername(username: String) {
        prefs.edit().putString(KEY_CURRENT_USERNAME, username).apply()
    }
    
    fun getCurrentUsername(): String? {
        return prefs.getString(KEY_CURRENT_USERNAME, null)
    }
    
    fun logout() {
        prefs.edit().apply {
            putBoolean(KEY_IS_LOGGED_IN, false)
            putString(KEY_CURRENT_USERNAME, "")
            apply()
        }
    }
    
    fun hasAccount(): Boolean {
        return getUserAccount() != null
    }
}
