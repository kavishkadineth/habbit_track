package com.example.labexam03new.fragments

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.labexam03new.LoginActivity
import com.example.labexam03new.MainActivity
import com.example.labexam03new.R
import com.example.labexam03new.data.SharedPreferencesManager
import com.example.labexam03new.databinding.FragmentProfileBinding
import com.example.labexam03new.models.UserProfile
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * ProfileFragment - Manages user profile creation and viewing
 * Features:
 * - Create new user profile
 * - View existing profile details
 * - Edit profile information
 * - Display health statistics (BMI, recommended water intake)
 * - Personalized recommendations
 */
class ProfileFragment : Fragment() {
    
    private var _binding: FragmentProfileBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var prefsManager: SharedPreferencesManager
    private var userProfile: UserProfile? = null
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentProfileBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        // Initialize SharedPreferences manager
        prefsManager = (requireActivity() as MainActivity).getPrefsManager()
        
        setupClickListeners()
        loadProfile()
    }
    
    /**
     * Sets up click listeners
     */
    private fun setupClickListeners() {
        binding.btnCreateProfile.setOnClickListener {
            showCreateEditProfileDialog(isEdit = false)
        }
        
        binding.btnEditProfile.setOnClickListener {
            showCreateEditProfileDialog(isEdit = true)
        }
        
        binding.btnLogout.setOnClickListener {
            showLogoutConfirmationDialog()
        }
    }
    
    /**
     * Loads user profile from SharedPreferences
     */
    private fun loadProfile() {
        userProfile = prefsManager.getUserProfile()
        
        if (userProfile != null) {
            displayProfile(userProfile!!)
        } else {
            showCreateProfilePrompt()
        }
    }
    
    /**
     * Displays user profile information
     */
    private fun displayProfile(profile: UserProfile) {
        binding.apply {
            // Hide create profile card, show profile info
            cardCreateProfile.visibility = View.GONE
            cardPersonalInfo.visibility = View.VISIBLE
            cardHealthStats.visibility = View.VISIBLE
            
            // Display user information
            val currentUsername = prefsManager.getCurrentUsername()
            tvUserName.text = if (currentUsername != null && currentUsername.isNotEmpty()) {
                "Welcome, $currentUsername!"
            } else if (profile.name.isNotEmpty()) {
                profile.name
            } else {
                "Welcome!"
            }
            
            tvUserEmail.text = profile.email
            tvUserEmail.visibility = if (profile.email.isNotEmpty()) View.VISIBLE else View.GONE
            
            // Display personal information
            tvAge.text = "${profile.age} years"
            tvGender.text = profile.gender.ifEmpty { "--" }
            tvWeight.text = if (profile.weight > 0) "${profile.weight} kg" else "-- kg"
            tvHeight.text = if (profile.height > 0) "${profile.height} cm" else "-- cm"
            
            // Display health statistics
            if (profile.weight > 0 && profile.height > 0) {
                val bmi = profile.calculateBMI()
                tvBmi.text = String.format("%.1f", bmi)
                tvBmiCategory.text = profile.getBMICategory()
                
                // Set BMI color based on category
                val bmiColor = when (profile.getBMICategory()) {
                    "Normal" -> requireContext().getColor(R.color.wellness_primary)
                    "Underweight", "Overweight" -> requireContext().getColor(R.color.mood_neutral)
                    else -> requireContext().getColor(R.color.error)
                }
                tvBmi.setTextColor(bmiColor)
            } else {
                tvBmi.text = "--"
                tvBmiCategory.text = "Add weight and height to calculate"
            }
            
            // Display recommended water intake
            val recommendedWater = profile.getRecommendedWaterIntake()
            tvRecommendedWater.text = "$recommendedWater ml/day"
        }
    }
    
    /**
     * Shows create profile prompt for new users
     */
    private fun showCreateProfilePrompt() {
        binding.apply {
            cardCreateProfile.visibility = View.VISIBLE
            cardPersonalInfo.visibility = View.GONE
            cardHealthStats.visibility = View.GONE
            
            // Show username if available
            val currentUsername = prefsManager.getCurrentUsername()
            tvUserName.text = if (currentUsername != null && currentUsername.isNotEmpty()) {
                "Welcome, $currentUsername!"
            } else {
                "Welcome!"
            }
            tvUserEmail.visibility = View.GONE
        }
    }
    
    /**
     * Shows dialog to create or edit profile
     */
    private fun showCreateEditProfileDialog(isEdit: Boolean) {
        val dialogView = LayoutInflater.from(requireContext())
            .inflate(R.layout.dialog_create_edit_profile, null)
        
        // Pre-populate fields if editing
        if (isEdit && userProfile != null) {
            populateProfileDialog(dialogView, userProfile!!)
        }
        
        val dialog = MaterialAlertDialogBuilder(requireContext())
            .setTitle(if (isEdit) "Edit Profile" else "Create Profile")
            .setView(dialogView)
            .setPositiveButton(if (isEdit) "Save" else "Create") { _, _ ->
                saveProfileFromDialog(dialogView)
            }
            .setNegativeButton("Cancel", null)
            .create()
        
        dialog.show()
    }
    
    /**
     * Populates dialog fields with existing profile data
     */
    private fun populateProfileDialog(dialogView: View, profile: UserProfile) {
        dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_profile_name)
            ?.setText(profile.name)
        dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_profile_email)
            ?.setText(profile.email)
        dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_profile_age)
            ?.setText(if (profile.age > 0) profile.age.toString() else "")
        dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_profile_gender)
            ?.setText(profile.gender)
        dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_profile_weight)
            ?.setText(if (profile.weight > 0) profile.weight.toString() else "")
        dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_profile_height)
            ?.setText(if (profile.height > 0) profile.height.toString() else "")
        dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_profile_water_goal)
            ?.setText(profile.dailyWaterGoal.toString())
        dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_profile_steps_goal)
            ?.setText(profile.dailyStepsGoal.toString())
    }
    
    /**
     * Saves profile from dialog input
     */
    private fun saveProfileFromDialog(dialogView: View) {
        val name = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_profile_name)
            ?.text?.toString()?.trim() ?: ""
        val email = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_profile_email)
            ?.text?.toString()?.trim() ?: ""
        val age = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_profile_age)
            ?.text?.toString()?.toIntOrNull() ?: 0
        val gender = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_profile_gender)
            ?.text?.toString()?.trim() ?: ""
        val weight = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_profile_weight)
            ?.text?.toString()?.toDoubleOrNull() ?: 0.0
        val height = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_profile_height)
            ?.text?.toString()?.toDoubleOrNull() ?: 0.0
        val waterGoal = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_profile_water_goal)
            ?.text?.toString()?.toIntOrNull() ?: 2000
        val stepsGoal = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_profile_steps_goal)
            ?.text?.toString()?.toIntOrNull() ?: 10000
        
        // Validate required fields
        if (name.isEmpty()) {
            Toast.makeText(requireContext(), "Please enter your name", Toast.LENGTH_SHORT).show()
            return
        }
        
        if (age <= 0) {
            Toast.makeText(requireContext(), "Please enter a valid age", Toast.LENGTH_SHORT).show()
            return
        }
        
        // Create profile
        val profile = UserProfile(
            name = name,
            email = email,
            age = age,
            gender = gender,
            weight = weight,
            height = height,
            dailyWaterGoal = waterGoal,
            dailyStepsGoal = stepsGoal,
            profileCreatedAt = userProfile?.profileCreatedAt ?: System.currentTimeMillis()
        )
        
        // Save profile
        prefsManager.saveUserProfile(profile)
        
        // Update hydration goal in settings
        prefsManager.setDailyWaterGoal(waterGoal)
        
        // Reload profile
        loadProfile()
        
        Toast.makeText(
            requireContext(),
            if (userProfile == null) "Profile created successfully!" else "Profile updated successfully!",
            Toast.LENGTH_SHORT
        ).show()
    }
    
    /**
     * Shows logout confirmation dialog
     */
    private fun showLogoutConfirmationDialog() {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Logout")
            .setMessage("Are you sure you want to logout? You'll need to login again to access the app.")
            .setIcon(R.drawable.ic_logout)
            .setPositiveButton("Logout") { _, _ ->
                performLogout()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    /**
     * Performs logout and navigates to login screen
     */
    private fun performLogout() {
        // Logout user
        prefsManager.logout()
        
        // Show toast
        Toast.makeText(requireContext(), "Logged out successfully", Toast.LENGTH_SHORT).show()
        
        // Navigate to login activity
        val intent = Intent(requireContext(), LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        requireActivity().finish()
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
