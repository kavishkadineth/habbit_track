package com.example.labexam03new.models

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Data class representing a mood journal entry
 * @param id Unique identifier for the mood entry
 * @param emoji Emoji representing the mood
 * @param note Optional note describing the mood or situation
 * @param timestamp When the mood was recorded
 * @param moodLevel Numeric mood level (1-10 scale)
 */
data class MoodEntry(
    val id: String = UUID.randomUUID().toString(),
    val emoji: String,
    val note: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val moodLevel: Int = 5
) {
    
    companion object {
        // Predefined mood emojis for the selector
        val MOOD_EMOJIS = listOf(
            "😢", "😔", "😐", "😊", "😄", "🤩",
            "😴", "😌", "🤔", "😤", "😍", "🎉"
        )
        
        val MOOD_LEVELS = mapOf(
            "😢" to 1, "😔" to 2, "😐" to 3, "😊" to 4, "😄" to 5, "🤩" to 6,
            "😴" to 3, "😌" to 4, "🤔" to 3, "😤" to 2, "😍" to 5, "🎉" to 6
        )
    }
    
    /**
     * Gets formatted date string
     * @return Date in "MMM dd, yyyy" format
     */
    fun getFormattedDate(): String {
        val dateFormat = SimpleDateFormat("MMM dd, yyyy", Locale.getDefault())
        return dateFormat.format(Date(timestamp))
    }
    
    /**
     * Gets formatted time string
     * @return Time in "HH:mm" format
     */
    fun getFormattedTime(): String {
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        return timeFormat.format(Date(timestamp))
    }
    
    /**
     * Gets full formatted date and time
     * @return Date and time in "MMM dd, yyyy HH:mm" format
     */
    fun getFormattedDateTime(): String {
        val dateTimeFormat = SimpleDateFormat("MMM dd, yyyy HH:mm", Locale.getDefault())
        return dateTimeFormat.format(Date(timestamp))
    }
    
    /**
     * Gets mood description based on emoji
     * @return Human-readable mood description
     */
    fun getMoodDescription(): String {
        return when (emoji) {
            "😢" -> "Very Sad"
            "😔" -> "Sad"
            "😐" -> "Neutral"
            "😊" -> "Happy"
            "😄" -> "Very Happy"
            "🤩" -> "Excited"
            "😴" -> "Tired"
            "😌" -> "Peaceful"
            "🤔" -> "Thoughtful"
            "😤" -> "Frustrated"
            "😍" -> "In Love"
            "🎉" -> "Celebrating"
            else -> "Unknown"
        }
    }
}
