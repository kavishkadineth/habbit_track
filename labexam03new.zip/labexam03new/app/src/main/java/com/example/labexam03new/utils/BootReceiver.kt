package com.example.labexam03new.utils

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.labexam03new.data.SharedPreferencesManager
import java.util.Calendar

/**
 * BroadcastReceiver for handling device boot completion
 * Features:
 * - Restarts hydration reminders after device reboot
 * - Ensures reminders continue working after system restart
 */
class BootReceiver : BroadcastReceiver() {
    
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED) {
            // Restart hydration reminders if they were enabled
            val prefsManager = SharedPreferencesManager(context)
            
            if (prefsManager.isHydrationReminderEnabled()) {
                val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                val interval = prefsManager.getHydrationInterval()
                
                val reminderIntent = Intent(context, HydrationReminderReceiver::class.java)
                val pendingIntent = PendingIntent.getBroadcast(
                    context,
                    0,
                    reminderIntent,
                    PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                )
                
                // Schedule reminder to start in the specified interval
                val calendar = Calendar.getInstance()
                calendar.add(Calendar.MINUTE, interval)
                
                alarmManager.setRepeating(
                    AlarmManager.RTC_WAKEUP,
                    calendar.timeInMillis,
                    interval * 60 * 1000L, // Convert minutes to milliseconds
                    pendingIntent
                )
            }
        }
    }
}
