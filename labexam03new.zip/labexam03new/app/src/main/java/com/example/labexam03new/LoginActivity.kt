package com.example.labexam03new

import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.labexam03new.data.SharedPreferencesManager
import com.example.labexam03new.databinding.ActivityLoginBinding
import com.example.labexam03new.models.UserAccount
import com.google.android.material.tabs.TabLayout
import java.security.MessageDigest

/**
 * LoginActivity - Handles user authentication
 * Features:
 * - User login with username and password
 * - User signup/registration
 * - Tab-based UI for login/signup
 * - Password hashing for security
 * - Session management
 */
class LoginActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityLoginBinding
    private lateinit var prefsManager: SharedPreferencesManager
    private var isLoginMode = true
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        prefsManager = SharedPreferencesManager(this)
        
        // Check if user is already logged in
        if (prefsManager.isLoggedIn() && prefsManager.hasAccount()) {
            navigateToMainActivity()
            return
        }
        
        // If account exists, start in login mode, otherwise signup mode
        if (prefsManager.hasAccount()) {
            binding.tabLayout.getTabAt(0)?.select()
        } else {
            binding.tabLayout.getTabAt(1)?.select()
        }
        
        setupTabLayout()
        setupClickListeners()
    }
    
    /**
     * Sets up the tab layout for login/signup
     */
    private fun setupTabLayout() {
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab?) {
                when (tab?.position) {
                    0 -> switchToLoginMode()
                    1 -> switchToSignupMode()
                }
            }
            
            override fun onTabUnselected(tab: TabLayout.Tab?) {}
            override fun onTabReselected(tab: TabLayout.Tab?) {}
        })
    }
    
    /**
     * Sets up click listeners
     */
    private fun setupClickListeners() {
        binding.btnAuth.setOnClickListener {
            if (isLoginMode) {
                performLogin()
            } else {
                performSignup()
            }
        }
        
        // Reset account button for testing
        binding.btnResetAccount.setOnClickListener {
            showResetAccountDialog()
        }
    }
    
    /**
     * Switches to login mode
     */
    private fun switchToLoginMode() {
        isLoginMode = true
        binding.apply {
            tilEmail.visibility = android.view.View.GONE
            tilConfirmPassword.visibility = android.view.View.GONE
            btnAuth.text = "Login"
            tilUsername.hint = "Username"
        }
    }
    
    /**
     * Switches to signup mode
     */
    private fun switchToSignupMode() {
        isLoginMode = false
        binding.apply {
            tilEmail.visibility = android.view.View.VISIBLE
            tilConfirmPassword.visibility = android.view.View.VISIBLE
            btnAuth.text = "Sign Up"
            tilUsername.hint = "Username"
        }
    }
    
    /**
     * Performs user login
     */
    private fun performLogin() {
        val username = binding.etUsername.text.toString().trim()
        val password = binding.etPassword.text.toString()
        
        // Validate input
        if (username.isEmpty()) {
            binding.tilUsername.error = "Please enter username"
            return
        }
        
        if (password.isEmpty()) {
            binding.tilPassword.error = "Please enter password"
            return
        }
        
        // Clear errors
        binding.tilUsername.error = null
        binding.tilPassword.error = null
        
        // Get stored account
        val storedAccount = prefsManager.getUserAccount()
        
        if (storedAccount == null) {
            Toast.makeText(this, "No account found. Please sign up first.", Toast.LENGTH_SHORT).show()
            binding.tabLayout.getTabAt(1)?.select()
            return
        }
        
        // Verify credentials
        val hashedPassword = hashPassword(password)
        
        // Debug logging (remove in production)
        android.util.Log.d("LoginActivity", "Login attempt - Username: $username")
        android.util.Log.d("LoginActivity", "Stored username: ${storedAccount.username}")
        android.util.Log.d("LoginActivity", "Password match: ${storedAccount.password == hashedPassword}")
        
        if (storedAccount.username == username && storedAccount.password == hashedPassword) {
            // Login successful
            prefsManager.setLoggedIn(true)
            prefsManager.setCurrentUsername(username)
            
            Toast.makeText(this, "Welcome back, $username!", Toast.LENGTH_SHORT).show()
            navigateToMainActivity()
        } else {
            // Provide more specific error message
            if (storedAccount.username != username) {
                Toast.makeText(this, "Username not found. Please check your username or sign up.", Toast.LENGTH_LONG).show()
            } else {
                Toast.makeText(this, "Incorrect password. Please try again.", Toast.LENGTH_LONG).show()
            }
        }
    }
    
    /**
     * Performs user signup
     */
    private fun performSignup() {
        val username = binding.etUsername.text.toString().trim()
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString()
        val confirmPassword = binding.etConfirmPassword.text.toString()
        
        // Validate input
        if (username.isEmpty()) {
            binding.tilUsername.error = "Please enter username"
            return
        }
        
        if (username.length < 3) {
            binding.tilUsername.error = "Username must be at least 3 characters"
            return
        }
        
        if (email.isEmpty()) {
            binding.tilEmail.error = "Please enter email"
            return
        }
        
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            binding.tilEmail.error = "Please enter a valid email"
            return
        }
        
        if (password.isEmpty()) {
            binding.tilPassword.error = "Please enter password"
            return
        }
        
        if (password.length < 6) {
            binding.tilPassword.error = "Password must be at least 6 characters"
            return
        }
        
        if (confirmPassword.isEmpty()) {
            binding.tilConfirmPassword.error = "Please confirm password"
            return
        }
        
        if (password != confirmPassword) {
            binding.tilConfirmPassword.error = "Passwords do not match"
            return
        }
        
        // Clear errors
        binding.tilUsername.error = null
        binding.tilEmail.error = null
        binding.tilPassword.error = null
        binding.tilConfirmPassword.error = null
        
        // Check if account already exists
        val existingAccount = prefsManager.getUserAccount()
        if (existingAccount != null) {
            Toast.makeText(this, "An account already exists. Please login.", Toast.LENGTH_SHORT).show()
            binding.tabLayout.getTabAt(0)?.select()
            return
        }
        
        // Create new account
        val hashedPassword = hashPassword(password)
        val newAccount = UserAccount(
            username = username,
            password = hashedPassword,
            email = email,
            isLoggedIn = true
        )
        
        prefsManager.saveUserAccount(newAccount)
        prefsManager.setLoggedIn(true)
        prefsManager.setCurrentUsername(username)
        
        Toast.makeText(this, "Account created successfully! Welcome, $username!", Toast.LENGTH_SHORT).show()
        navigateToMainActivity()
    }
    
    /**
     * Hashes password using SHA-256
     */
    private fun hashPassword(password: String): String {
        val bytes = password.toByteArray()
        val md = MessageDigest.getInstance("SHA-256")
        val digest = md.digest(bytes)
        return digest.fold("") { str, it -> str + "%02x".format(it) }
    }
    
    /**
     * Shows dialog to reset account (for testing)
     */
    private fun showResetAccountDialog() {
        val account = prefsManager.getUserAccount()
        
        val message = if (account != null) {
            "Current Account:\nUsername: ${account.username}\nEmail: ${account.email}\n\nThis will delete your account and all data. Are you sure?"
        } else {
            "No account found to reset."
        }
        
        com.google.android.material.dialog.MaterialAlertDialogBuilder(this)
            .setTitle("Reset Account")
            .setMessage(message)
            .setPositiveButton("Reset") { _, _ ->
                if (account != null) {
                    resetAccount()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    /**
     * Resets the account (for testing purposes)
     */
    private fun resetAccount() {
        // Clear all authentication data
        prefsManager.clearAllData()
        
        Toast.makeText(this, "Account reset successfully. You can now create a new account.", Toast.LENGTH_LONG).show()
        
        // Switch to signup mode
        binding.tabLayout.getTabAt(1)?.select()
        
        // Clear input fields
        binding.etUsername.text?.clear()
        binding.etEmail.text?.clear()
        binding.etPassword.text?.clear()
        binding.etConfirmPassword.text?.clear()
    }
    
    /**
     * Navigates to MainActivity
     */
    private fun navigateToMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}
