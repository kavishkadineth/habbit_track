package com.example.labexam03new.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.labexam03new.databinding.ItemHabitBinding
import com.example.labexam03new.models.Habit

/**
 * RecyclerView Adapter for displaying habits
 * Features:
 * - Display habit information with progress
 * - Handle completion, edit, and delete actions
 * - Update progress bars and completion status
 */
class HabitAdapter(
    private var habits: List<Habit>,
    private val onCompleteClick: (Habit) -> Unit,
    private val onEditClick: (Habit) -> Unit,
    private val onDeleteClick: (Habit) -> Unit
) : RecyclerView.Adapter<HabitAdapter.HabitViewHolder>() {
    
    /**
     * ViewHolder for habit items
     */
    class HabitViewHolder(val binding: ItemHabitBinding) : RecyclerView.ViewHolder(binding.root)
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HabitViewHolder {
        val binding = ItemHabitBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return HabitViewHolder(binding)
    }
    
    override fun onBindViewHolder(holder: HabitViewHolder, position: Int) {
        val habit = habits[position]
        
        holder.binding.apply {
            // Set habit information
            tvHabitName.text = habit.name
            tvHabitDescription.text = habit.description
            chipCategory.text = habit.category
            
            // Update progress
            val progressPercentage = habit.getCompletionPercentage()
            tvProgressCount.text = "${habit.completedCount}/${habit.targetCount}"
            tvProgressPercentage.text = "$progressPercentage%"
            progressBarHabit.progress = progressPercentage
            
            // Update completion status
            if (habit.isFullyCompleted()) {
                // Habit is completed
                btnComplete.setIconResource(com.example.labexam03new.R.drawable.ic_check_circle)
                root.setBackgroundColor(root.context.getColor(com.example.labexam03new.R.color.completed_habit_background))
            } else {
                // Habit is not completed
                btnComplete.setIconResource(com.example.labexam03new.R.drawable.ic_check)
                root.setBackgroundColor(root.context.getColor(com.example.labexam03new.R.color.surface))
            }
            
            // Set click listeners
            btnComplete.setOnClickListener {
                onCompleteClick(habit)
            }
            
            btnEdit.setOnClickListener {
                onEditClick(habit)
            }
            
            btnDelete.setOnClickListener {
                onDeleteClick(habit)
            }
        }
    }
    
    override fun getItemCount(): Int = habits.size
    
    /**
     * Updates the habits list
     */
    fun updateHabits(newHabits: List<Habit>) {
        habits = newHabits
        notifyDataSetChanged()
    }
}
