package com.example.labexam03new.utils

import com.example.labexam03new.data.SharedPreferencesManager
import com.example.labexam03new.models.Habit
import com.example.labexam03new.models.MoodEntry

/**
 * Utility class for generating sample data for testing and demonstration
 * Features:
 * - Creates sample habits for quick testing
 * - Generates sample mood entries
 * - Useful for app demonstrations
 */
object SampleDataGenerator {
    
    /**
     * Generates sample habits for demonstration
     */
    fun generateSampleHabits(): List<Habit> {
        return listOf(
            Habit(
                name = "Drink Water",
                description = "Stay hydrated throughout the day",
                targetCount = 8,
                completedCount = 5,
                category = "Health",
                isCompleted = false
            ),
            Habit(
                name = "Morning Meditation",
                description = "Start the day with mindfulness",
                targetCount = 1,
                completedCount = 1,
                category = "Mindfulness",
                isCompleted = true
            ),
            Habit(
                name = "Take 10,000 Steps",
                description = "Stay active and healthy",
                targetCount = 1,
                completedCount = 0,
                category = "Exercise",
                isCompleted = false
            ),
            Habit(
                name = "Read for 30 Minutes",
                description = "Expand knowledge and relax",
                targetCount = 1,
                completedCount = 1,
                category = "Learning",
                isCompleted = true
            ),
            Habit(
                name = "Practice Gratitude",
                description = "Write down three things you're grateful for",
                targetCount = 1,
                completedCount = 0,
                category = "Mindfulness",
                isCompleted = false
            )
        )
    }
    
    /**
     * Generates sample mood entries for demonstration
     */
    fun generateSampleMoodEntries(): List<MoodEntry> {
        val currentTime = System.currentTimeMillis()
        val dayInMillis = 24 * 60 * 60 * 1000L
        
        return listOf(
            MoodEntry(
                emoji = "😊",
                note = "Had a great day at work!",
                timestamp = currentTime - (dayInMillis * 1),
                moodLevel = 5
            ),
            MoodEntry(
                emoji = "😴",
                note = "Feeling tired but accomplished",
                timestamp = currentTime - (dayInMillis * 2),
                moodLevel = 3
            ),
            MoodEntry(
                emoji = "🤩",
                note = "Excited about the new project!",
                timestamp = currentTime - (dayInMillis * 3),
                moodLevel = 6
            ),
            MoodEntry(
                emoji = "😐",
                note = "Average day, nothing special",
                timestamp = currentTime - (dayInMillis * 4),
                moodLevel = 3
            ),
            MoodEntry(
                emoji = "😌",
                note = "Peaceful evening with family",
                timestamp = currentTime - (dayInMillis * 5),
                moodLevel = 4
            ),
            MoodEntry(
                emoji = "😄",
                note = "Celebrated a friend's birthday!",
                timestamp = currentTime - (dayInMillis * 6),
                moodLevel = 5
            ),
            MoodEntry(
                emoji = "🤔",
                note = "Reflecting on life decisions",
                timestamp = currentTime - (dayInMillis * 7),
                moodLevel = 3
            )
        )
    }
    
    /**
     * Initializes the app with sample data
     * Call this method to populate the app with demonstration data
     */
    fun initializeWithSampleData(prefsManager: SharedPreferencesManager) {
        // Add sample habits
        val sampleHabits = generateSampleHabits()
        prefsManager.saveHabits(sampleHabits)
        
        // Add sample mood entries
        val sampleMoodEntries = generateSampleMoodEntries()
        prefsManager.saveMoodEntries(sampleMoodEntries)
        
        // Set default settings
        prefsManager.setDailyWaterGoal(2000)
        prefsManager.setWaterConsumed(800)
        prefsManager.setHydrationInterval(120) // 2 hours
        prefsManager.setHydrationReminderEnabled(false) // Start with reminders disabled
    }
    
    /**
     * Clears all data from the app
     */
    fun clearAllData(prefsManager: SharedPreferencesManager) {
        prefsManager.clearAllData()
    }
}
