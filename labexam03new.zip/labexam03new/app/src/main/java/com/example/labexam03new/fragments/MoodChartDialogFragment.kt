package com.example.labexam03new.fragments

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.DialogFragment
import com.example.labexam03new.R
import com.example.labexam03new.data.SharedPreferencesManager
import com.example.labexam03new.databinding.DialogMoodChartBinding
import com.example.labexam03new.models.MoodEntry
import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import java.text.SimpleDateFormat
import java.util.*

/**
 * DialogFragment for displaying mood trend chart
 * Features:
 * - Line chart showing mood trends over the last 7 days
 * - Interactive chart with mood level visualization
 * - Uses MPAndroidChart library
 */
class MoodChartDialogFragment : DialogFragment() {
    
    private var _binding: DialogMoodChartBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var prefsManager: SharedPreferencesManager
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = DialogMoodChartBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        // Initialize SharedPreferences manager
        prefsManager = (requireActivity() as com.example.labexam03new.MainActivity).getPrefsManager()
        
        setupChart()
        loadMoodData()
    }
    
    override fun onStart() {
        super.onStart()
        
        // Set dialog size
        dialog?.window?.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
    }
    
    /**
     * Sets up the mood chart
     */
    private fun setupChart() {
        val chart = binding.lineChartMood
        
        // Configure chart appearance
        chart.apply {
            description.isEnabled = false
            setTouchEnabled(true)
            isDragEnabled = true
            setScaleEnabled(true)
            setPinchZoom(true)
            
            // Configure axes
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                granularity = 1f
                setDrawGridLines(false)
                setDrawAxisLine(true)
            }
            
            axisLeft.apply {
                setDrawGridLines(true)
                axisMinimum = 1f
                axisMaximum = 6f
                granularity = 1f
            }
            
            axisRight.isEnabled = false
            
            // Configure legend
            legend.isEnabled = false
        }
    }
    
    /**
     * Loads and displays mood data in the chart
     */
    private fun loadMoodData() {
        val moodEntries = prefsManager.getMoodEntries()
        
        if (moodEntries.isEmpty()) {
            binding.tvNoData.visibility = View.VISIBLE
            binding.lineChartMood.visibility = View.GONE
            return
        }
        
        binding.tvNoData.visibility = View.GONE
        binding.lineChartMood.visibility = View.VISIBLE
        
        // Get mood entries from the last 7 days
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.DAY_OF_YEAR, -7)
        val weekAgo = calendar.timeInMillis
        
        val recentEntries = moodEntries
            .filter { it.timestamp >= weekAgo }
            .sortedBy { it.timestamp }
        
        if (recentEntries.isEmpty()) {
            binding.tvNoData.visibility = View.VISIBLE
            binding.lineChartMood.visibility = View.GONE
            return
        }
        
        // Create chart data
        val entries = mutableListOf<Entry>()
        val labels = mutableListOf<String>()
        
        // Group entries by day and calculate average mood for each day
        val entriesByDay = recentEntries.groupBy { 
            val date = Date(it.timestamp)
            SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(date)
        }
        
        var index = 0f
        entriesByDay.toSortedMap().forEach { (dateStr, dayEntries) ->
            val averageMood = dayEntries.map { it.moodLevel }.average().toFloat()
            entries.add(Entry(index, averageMood))
            
            // Format date for display
            val date = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(dateStr)
            val displayDate = SimpleDateFormat("MMM dd", Locale.getDefault()).format(date!!)
            labels.add(displayDate)
            
            index++
        }
        
        // Create dataset
        val dataSet = LineDataSet(entries, "Mood Level").apply {
            color = requireContext().getColor(R.color.wellness_primary)
            setCircleColor(requireContext().getColor(R.color.wellness_secondary))
            lineWidth = 3f
            circleRadius = 6f
            setDrawCircleHole(true)
            circleHoleColor = requireContext().getColor(R.color.wellness_secondary)
            setDrawFilled(true)
            fillColor = requireContext().getColor(R.color.wellness_accent)
            fillAlpha = 100
        }
        
        // Set data and labels
        val lineData = LineData(dataSet)
        binding.lineChartMood.data = lineData
        binding.lineChartMood.xAxis.valueFormatter = IndexAxisValueFormatter(labels)
        
        // Refresh chart
        binding.lineChartMood.invalidate()
        
        // Update summary text
        val totalEntries = recentEntries.size
        val averageMood = recentEntries.map { it.moodLevel }.average()
        val moodDescription = when {
            averageMood >= 5 -> "Great"
            averageMood >= 4 -> "Good"
            averageMood >= 3 -> "Okay"
            else -> "Could be better"
        }
        
        binding.tvMoodSummary.text = "Last 7 days: $totalEntries entries, $moodDescription mood"
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
