package com.example.labexam03new.fragments

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.example.labexam03new.R
import com.example.labexam03new.data.SharedPreferencesManager
import com.example.labexam03new.databinding.FragmentHydrationReminderBinding
import com.example.labexam03new.utils.HydrationReminderReceiver
import java.util.Calendar

/**
 * HydrationReminderFragment - Manages water intake tracking and reminders
 * Features:
 * - Daily water goal tracking with progress bar
 * - Quick add water buttons
 * - Configurable reminder intervals
 * - Notification-based reminders using AlarmManager
 */
class HydrationReminderFragment : Fragment() {
    
    private var _binding: FragmentHydrationReminderBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var prefsManager: SharedPreferencesManager
    private lateinit var alarmManager: AlarmManager
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHydrationReminderBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        // Initialize managers
        prefsManager = (requireActivity() as com.example.labexam03new.MainActivity).getPrefsManager()
        alarmManager = requireContext().getSystemService(Context.ALARM_SERVICE) as AlarmManager
        
        setupClickListeners()
        loadSettings()
        updateWaterDisplay()
        checkDailyReset()
    }
    
    /**
     * Sets up click listeners for all buttons
     */
    private fun setupClickListeners() {
        // Quick add water buttons
        binding.btnAdd100ml.setOnClickListener { addWater(100) }
        binding.btnAdd250ml.setOnClickListener { addWater(250) }
        binding.btnAdd500ml.setOnClickListener { addWater(500) }
        
        // Reset water button
        binding.btnResetWater.setOnClickListener { showResetWaterDialog() }
        
        // Reminder interval buttons
        binding.btnInterval60.setOnClickListener { setReminderInterval(60) }
        binding.btnInterval120.setOnClickListener { setReminderInterval(120) }
        binding.btnInterval180.setOnClickListener { setReminderInterval(180) }
        
        // Reminder switch
        binding.switchReminderEnabled.setOnCheckedChangeListener { _, isChecked ->
            prefsManager.setHydrationReminderEnabled(isChecked)
            if (isChecked) {
                scheduleReminder()
                Toast.makeText(requireContext(), "Hydration reminders enabled", Toast.LENGTH_SHORT).show()
            } else {
                cancelReminder()
                Toast.makeText(requireContext(), "Hydration reminders disabled", Toast.LENGTH_SHORT).show()
            }
        }
        
        // Save water goal
        binding.etWaterGoal.setOnFocusChangeListener { _, hasFocus ->
            if (!hasFocus) {
                saveWaterGoal()
            }
        }
    }
    
    /**
     * Loads settings from SharedPreferences
     */
    private fun loadSettings() {
        // Load water goal
        val waterGoal = prefsManager.getDailyWaterGoal()
        binding.etWaterGoal.setText(waterGoal.toString())
        
        // Load reminder settings
        binding.switchReminderEnabled.isChecked = prefsManager.isHydrationReminderEnabled()
        
        // Highlight current interval
        val currentInterval = prefsManager.getHydrationInterval()
        updateIntervalButtons(currentInterval)
    }
    
    /**
     * Updates the water display with current values
     */
    private fun updateWaterDisplay() {
        val consumed = prefsManager.getWaterConsumed()
        val goal = prefsManager.getDailyWaterGoal()
        
        binding.apply {
            tvWaterConsumed.text = consumed.toString()
            tvWaterGoal.text = goal.toString()
            
            val percentage = if (goal > 0) {
                ((consumed.toFloat() / goal.toFloat()) * 100).toInt()
            } else {
                0
            }
            
            progressBarWater.progress = percentage
            tvWaterPercentage.text = "$percentage%"
        }
    }
    
    /**
     * Adds water to the daily consumption
     */
    private fun addWater(amount: Int) {
        val currentConsumed = prefsManager.getWaterConsumed()
        val newConsumed = currentConsumed + amount
        prefsManager.setWaterConsumed(newConsumed)
        
        updateWaterDisplay()
        
        val goal = prefsManager.getDailyWaterGoal()
        if (newConsumed >= goal) {
            Toast.makeText(requireContext(), "🎉 Congratulations! You've reached your daily water goal!", Toast.LENGTH_LONG).show()
        } else {
            Toast.makeText(requireContext(), "Added ${amount}ml of water", Toast.LENGTH_SHORT).show()
        }
    }
    
    /**
     * Sets the reminder interval
     */
    private fun setReminderInterval(minutes: Int) {
        prefsManager.setHydrationInterval(minutes)
        updateIntervalButtons(minutes)
        
        if (prefsManager.isHydrationReminderEnabled()) {
            scheduleReminder()
        }
        
        Toast.makeText(requireContext(), "Reminder interval set to ${minutes} minutes", Toast.LENGTH_SHORT).show()
    }
    
    /**
     * Updates the interval button appearance
     */
    private fun updateIntervalButtons(selectedMinutes: Int) {
        val buttons = listOf(
            binding.btnInterval60 to 60,
            binding.btnInterval120 to 120,
            binding.btnInterval180 to 180
        )
        
        buttons.forEach { (button, minutes) ->
            if (minutes == selectedMinutes) {
                button.setBackgroundColor(requireContext().getColor(R.color.wellness_primary))
                button.setTextColor(requireContext().getColor(R.color.white))
            } else {
                button.setBackgroundColor(requireContext().getColor(R.color.surface))
                button.setTextColor(requireContext().getColor(R.color.on_surface))
            }
        }
    }
    
    /**
     * Saves the water goal from the text field
     */
    private fun saveWaterGoal() {
        val goalText = binding.etWaterGoal.text.toString()
        val goal = goalText.toIntOrNull() ?: 2000
        
        prefsManager.setDailyWaterGoal(goal)
        updateWaterDisplay()
        
        Toast.makeText(requireContext(), "Daily goal updated to ${goal}ml", Toast.LENGTH_SHORT).show()
    }
    
    /**
     * Schedules hydration reminders using AlarmManager
     */
    private fun scheduleReminder() {
        val interval = prefsManager.getHydrationInterval()
        
        val intent = Intent(requireContext(), HydrationReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            requireContext(),
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        // Set first reminder to trigger in the specified interval
        val calendar = Calendar.getInstance()
        calendar.add(Calendar.MINUTE, interval)
        
        alarmManager.setRepeating(
            AlarmManager.RTC_WAKEUP,
            calendar.timeInMillis,
            interval * 60 * 1000L, // Convert minutes to milliseconds
            pendingIntent
        )
    }
    
    /**
     * Cancels hydration reminders
     */
    private fun cancelReminder() {
        val intent = Intent(requireContext(), HydrationReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            requireContext(),
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        
        alarmManager.cancel(pendingIntent)
    }
    
    /**
     * Checks if daily reset is needed and resets water consumption
     */
    private fun checkDailyReset() {
        val today = getCurrentDate()
        val lastReset = prefsManager.getLastWaterResetDate()
        
        if (lastReset != today) {
            prefsManager.setWaterConsumed(0)
            prefsManager.setLastWaterResetDate(today)
            updateWaterDisplay()
        }
    }
    
    /**
     * Gets current date in YYYY-MM-DD format
     */
    private fun getCurrentDate(): String {
        val calendar = Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH) + 1
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        return "$year-$month-$day"
    }
    
    /**
     * Shows confirmation dialog to reset water intake
     */
    private fun showResetWaterDialog() {
        com.google.android.material.dialog.MaterialAlertDialogBuilder(requireContext())
            .setTitle("Reset Water Intake")
            .setMessage("Are you sure you want to reset your water intake to 0ml? This action cannot be undone.")
            .setIcon(R.drawable.ic_refresh)
            .setPositiveButton("Reset") { _, _ ->
                resetWaterIntake()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    /**
     * Resets the water intake to zero
     */
    private fun resetWaterIntake() {
        prefsManager.setWaterConsumed(0)
        updateWaterDisplay()
        Toast.makeText(requireContext(), "Water intake has been reset to 0ml", Toast.LENGTH_SHORT).show()
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
