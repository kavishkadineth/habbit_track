package com.example.labexam03new.models

/**
 * Data class for onboarding screen items
 * @param image Drawable resource ID for the onboarding image
 * @param title Title text for the onboarding screen
 * @param description Description text for the onboarding screen
 */
data class OnboardingItem(
    val image: Int,
    val title: String,
    val description: String
)
