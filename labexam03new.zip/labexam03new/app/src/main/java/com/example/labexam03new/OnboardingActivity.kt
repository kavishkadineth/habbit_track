package com.example.labexam03new

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.viewpager2.widget.ViewPager2
import com.example.labexam03new.adapters.OnboardingAdapter
import com.example.labexam03new.databinding.ActivityOnboardingBinding
import com.example.labexam03new.models.OnboardingItem

/**
 * OnboardingActivity - Shows introductory screens to new users
 * Features:
 * - 3 onboarding screens with images and descriptions
 * - Page indicators
 * - Skip and Next/Get Started buttons
 * - Saves onboarding completion status
 */
class OnboardingActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityOnboardingBinding
    private lateinit var onboardingAdapter: OnboardingAdapter
    private val onboardingItems = mutableListOf<OnboardingItem>()
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        binding = ActivityOnboardingBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        // Check if user is already logged in - go directly to main app
        if (isUserLoggedIn()) {
            navigateToMainApp()
            return
        }
        
        // Check if onboarding was already completed OR if user has an account
        if (isOnboardingCompleted() || hasUserAccount()) {
            navigateToLogin()
            return
        }
        
        setupOnboardingItems()
        setupViewPager()
        setupIndicators()
        setupClickListeners()
    }
    
    /**
     * Sets up the onboarding items
     */
    private fun setupOnboardingItems() {
        onboardingItems.add(
            OnboardingItem(
                image = R.drawable.ic_onboarding_habits,
                title = "Track Your Habits",
                description = "Build better habits and track your daily progress. Set goals and achieve them one step at a time."
            )
        )
        
        onboardingItems.add(
            OnboardingItem(
                image = R.drawable.ic_onboarding_mood,
                title = "Monitor Your Mood",
                description = "Log your daily mood with emojis and notes. Visualize your emotional wellness with beautiful charts."
            )
        )
        
        onboardingItems.add(
            OnboardingItem(
                image = R.drawable.ic_onboarding_hydration,
                title = "Stay Hydrated",
                description = "Set hydration goals and get reminders to drink water. Keep your body healthy and energized throughout the day."
            )
        )
    }
    
    /**
     * Sets up the ViewPager with adapter
     */
    private fun setupViewPager() {
        onboardingAdapter = OnboardingAdapter(onboardingItems)
        binding.viewPager.adapter = onboardingAdapter
        
        // Register page change callback
        binding.viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)
                updateIndicators(position)
                updateButtonText(position)
            }
        })
    }
    
    /**
     * Sets up page indicators
     */
    private fun setupIndicators() {
        val indicators = arrayOfNulls<ImageView>(onboardingItems.size)
        val layoutParams = LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        )
        layoutParams.setMargins(8, 0, 8, 0)
        
        for (i in indicators.indices) {
            indicators[i] = ImageView(this)
            indicators[i]?.setImageDrawable(
                ContextCompat.getDrawable(
                    this,
                    R.drawable.indicator_inactive
                )
            )
            indicators[i]?.layoutParams = layoutParams
            binding.layoutIndicators.addView(indicators[i])
        }
        
        // Set first indicator as active
        updateIndicators(0)
    }
    
    /**
     * Updates the page indicators
     */
    private fun updateIndicators(position: Int) {
        val childCount = binding.layoutIndicators.childCount
        for (i in 0 until childCount) {
            val imageView = binding.layoutIndicators.getChildAt(i) as ImageView
            if (i == position) {
                imageView.setImageDrawable(
                    ContextCompat.getDrawable(this, R.drawable.indicator_active)
                )
            } else {
                imageView.setImageDrawable(
                    ContextCompat.getDrawable(this, R.drawable.indicator_inactive)
                )
            }
        }
    }
    
    /**
     * Updates button text based on current page
     */
    private fun updateButtonText(position: Int) {
        if (position == onboardingItems.size - 1) {
            binding.btnNext.text = "Get Started"
            binding.btnSkip.visibility = View.GONE
        } else {
            binding.btnNext.text = "Next"
            binding.btnSkip.visibility = View.VISIBLE
        }
    }
    
    /**
     * Sets up click listeners
     */
    private fun setupClickListeners() {
        binding.btnNext.setOnClickListener {
            val currentItem = binding.viewPager.currentItem
            if (currentItem < onboardingItems.size - 1) {
                // Go to next page
                binding.viewPager.currentItem = currentItem + 1
            } else {
                // Complete onboarding
                completeOnboarding()
            }
        }
        
        binding.btnSkip.setOnClickListener {
            completeOnboarding()
        }
    }
    
    /**
     * Completes onboarding and navigates to login
     */
    private fun completeOnboarding() {
        // Save onboarding completion status
        val prefs = getSharedPreferences("wellness_app_prefs", MODE_PRIVATE)
        prefs.edit().putBoolean("onboarding_completed", true).apply()
        
        // Navigate to login
        navigateToLogin()
    }
    
    /**
     * Checks if onboarding was already completed
     */
    private fun isOnboardingCompleted(): Boolean {
        val prefs = getSharedPreferences("wellness_app_prefs", MODE_PRIVATE)
        return prefs.getBoolean("onboarding_completed", false)
    }
    
    /**
     * Checks if user has an account (skip onboarding for existing users)
     */
    private fun hasUserAccount(): Boolean {
        val prefs = getSharedPreferences("wellness_app_prefs", MODE_PRIVATE)
        val accountJson = prefs.getString("user_account", null)
        return accountJson != null && accountJson.isNotEmpty()
    }
    
    /**
     * Checks if user is currently logged in
     */
    private fun isUserLoggedIn(): Boolean {
        val prefs = getSharedPreferences("wellness_app_prefs", MODE_PRIVATE)
        return prefs.getBoolean("is_logged_in", false)
    }
    
    /**
     * Navigates to LoginActivity
     */
    private fun navigateToLogin() {
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
    
    /**
     * Navigates to MainActivity (for logged-in users)
     */
    private fun navigateToMainApp() {
        val intent = Intent(this, MainActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}
