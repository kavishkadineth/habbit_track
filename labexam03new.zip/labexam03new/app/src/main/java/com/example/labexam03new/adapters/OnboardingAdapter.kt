package com.example.labexam03new.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.labexam03new.databinding.ItemOnboardingBinding
import com.example.labexam03new.models.OnboardingItem

/**
 * RecyclerView Adapter for onboarding screens
 * Features:
 * - Display onboarding items with image, title, and description
 * - Support for ViewPager2
 */
class OnboardingAdapter(
    private val onboardingItems: List<OnboardingItem>
) : RecyclerView.Adapter<OnboardingAdapter.OnboardingViewHolder>() {
    
    /**
     * ViewHolder for onboarding items
     */
    class OnboardingViewHolder(val binding: ItemOnboardingBinding) : RecyclerView.ViewHolder(binding.root)
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OnboardingViewHolder {
        val binding = ItemOnboardingBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return OnboardingViewHolder(binding)
    }
    
    override fun onBindViewHolder(holder: OnboardingViewHolder, position: Int) {
        val item = onboardingItems[position]
        
        holder.binding.apply {
            ivOnboarding.setImageResource(item.image)
            tvTitle.text = item.title
            tvDescription.text = item.description
        }
    }
    
    override fun getItemCount(): Int = onboardingItems.size
}
