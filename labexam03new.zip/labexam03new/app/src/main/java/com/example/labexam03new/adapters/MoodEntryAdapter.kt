package com.example.labexam03new.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.labexam03new.databinding.ItemMoodEntryBinding
import com.example.labexam03new.models.MoodEntry

/**
 * RecyclerView Adapter for mood entries list
 * Features:
 * - Display mood entries with emoji, description, note, and timestamp
 * - Handle share functionality
 * - Show mood level indicator
 */
class MoodEntryAdapter(
    private var moodEntries: List<MoodEntry>,
    private val onShareClick: (MoodEntry) -> Unit
) : RecyclerView.Adapter<MoodEntryAdapter.MoodEntryViewHolder>() {
    
    /**
     * ViewHolder for mood entry items
     */
    class MoodEntryViewHolder(val binding: ItemMoodEntryBinding) : RecyclerView.ViewHolder(binding.root)
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MoodEntryViewHolder {
        val binding = ItemMoodEntryBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return MoodEntryViewHolder(binding)
    }
    
    override fun onBindViewHolder(holder: MoodEntryViewHolder, position: Int) {
        val moodEntry = moodEntries[position]
        
        holder.binding.apply {
            // Set mood information
            tvMoodEmoji.text = moodEntry.emoji
            tvMoodDescription.text = moodEntry.getMoodDescription()
            tvMoodLevel.text = moodEntry.moodLevel.toString()
            tvMoodTime.text = moodEntry.getFormattedDateTime()
            
            // Handle note visibility
            if (moodEntry.note.isNotEmpty()) {
                tvMoodNote.text = moodEntry.note
                tvMoodNote.visibility = android.view.View.VISIBLE
            } else {
                tvMoodNote.visibility = android.view.View.GONE
            }
            
            // Set mood level color based on level
            val color = when {
                moodEntry.moodLevel >= 5 -> holder.itemView.context.getColor(com.example.labexam03new.R.color.mood_happy)
                moodEntry.moodLevel >= 3 -> holder.itemView.context.getColor(com.example.labexam03new.R.color.mood_neutral)
                else -> holder.itemView.context.getColor(com.example.labexam03new.R.color.mood_sad)
            }
            tvMoodLevel.setTextColor(color)
            
            // Set click listener for sharing
            root.setOnClickListener {
                onShareClick(moodEntry)
            }
        }
    }
    
    override fun getItemCount(): Int = moodEntries.size
    
    /**
     * Updates the mood entries list
     */
    fun updateMoodEntries(newMoodEntries: List<MoodEntry>) {
        moodEntries = newMoodEntries
        notifyDataSetChanged()
    }
}
