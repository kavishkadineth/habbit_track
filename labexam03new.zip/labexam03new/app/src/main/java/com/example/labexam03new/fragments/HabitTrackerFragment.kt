package com.example.labexam03new.fragments

import android.app.AlertDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.labexam03new.R
import com.example.labexam03new.adapters.HabitAdapter
import com.example.labexam03new.data.SharedPreferencesManager
import com.example.labexam03new.databinding.FragmentHabitTrackerBinding
import com.example.labexam03new.models.Habit
import com.google.android.material.dialog.MaterialAlertDialogBuilder

/**
 * HabitTrackerFragment - Manages daily habit tracking
 * Features:
 * - Display daily progress with progress bar
 * - Add, edit, delete habits
 * - Mark habits as complete
 * - Show completion percentage
 */
class HabitTrackerFragment : Fragment() {
    
    private var _binding: FragmentHabitTrackerBinding? = null
    private val binding get() = _binding!!
    
    private lateinit var prefsManager: SharedPreferencesManager
    private lateinit var habitAdapter: HabitAdapter
    private var habits: MutableList<Habit> = mutableListOf()
    
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHabitTrackerBinding.inflate(inflater, container, false)
        return binding.root
    }
    
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        
        // Initialize SharedPreferences manager
        prefsManager = (requireActivity() as com.example.labexam03new.MainActivity).getPrefsManager()
        
        setupRecyclerView()
        setupClickListeners()
        loadHabits()
        updateDailyProgress()
    }
    
    /**
     * Sets up the RecyclerView for habits list
     */
    private fun setupRecyclerView() {
        habitAdapter = HabitAdapter(
            habits = habits,
            onCompleteClick = { habit -> completeHabit(habit) },
            onEditClick = { habit -> showEditHabitDialog(habit) },
            onDeleteClick = { habit -> showDeleteHabitDialog(habit) }
        )
        
        binding.recyclerViewHabits.apply {
            layoutManager = LinearLayoutManager(requireContext())
            adapter = habitAdapter
        }
    }
    
    /**
     * Sets up click listeners for buttons
     */
    private fun setupClickListeners() {
        binding.fabAddHabit.setOnClickListener {
            showAddHabitDialog()
        }
        
        binding.fabAddHabitMain.setOnClickListener {
            showAddHabitDialog()
        }
    }
    
    /**
     * Loads habits from SharedPreferences
     */
    private fun loadHabits() {
        habits.clear()
        habits.addAll(prefsManager.getHabits())
        habitAdapter.notifyDataSetChanged()
        updateDailyProgress()
    }
    
    /**
     * Updates the daily progress display
     */
    private fun updateDailyProgress() {
        val totalHabits = habits.size
        val completedHabits = habits.count { it.isFullyCompleted() }
        
        val percentage = if (totalHabits > 0) {
            (completedHabits.toFloat() / totalHabits.toFloat() * 100).toInt()
        } else {
            0
        }
        
        binding.apply {
            tvProgressPercentage.text = "$percentage%"
            progressBarDaily.progress = percentage
            tvProgressText.text = "$completedHabits of $totalHabits habits completed"
        }
    }
    
    /**
     * Shows dialog to add a new habit
     */
    private fun showAddHabitDialog() {
        val dialogView = LayoutInflater.from(requireContext())
            .inflate(R.layout.dialog_add_edit_habit, null)
        
        val dialog = MaterialAlertDialogBuilder(requireContext())
            .setTitle("Add New Habit")
            .setView(dialogView)
            .setPositiveButton("Add") { _, _ ->
                // Handle habit creation
                createHabitFromDialog(dialogView)
            }
            .setNegativeButton("Cancel", null)
            .create()
        
        dialog.show()
    }
    
    /**
     * Shows dialog to edit an existing habit
     */
    private fun showEditHabitDialog(habit: Habit) {
        val dialogView = LayoutInflater.from(requireContext())
            .inflate(R.layout.dialog_add_edit_habit, null)
        
        // Pre-populate fields
        populateHabitDialog(dialogView, habit)
        
        val dialog = MaterialAlertDialogBuilder(requireContext())
            .setTitle("Edit Habit")
            .setView(dialogView)
            .setPositiveButton("Save") { _, _ ->
                updateHabitFromDialog(habit, dialogView)
            }
            .setNegativeButton("Cancel", null)
            .create()
        
        dialog.show()
    }
    
    /**
     * Shows confirmation dialog to delete a habit
     */
    private fun showDeleteHabitDialog(habit: Habit) {
        MaterialAlertDialogBuilder(requireContext())
            .setTitle("Delete Habit")
            .setMessage("Are you sure you want to delete '${habit.name}'?")
            .setPositiveButton("Delete") { _, _ ->
                deleteHabit(habit)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
    
    /**
     * Completes a habit (increments completion count)
     */
    private fun completeHabit(habit: Habit) {
        val updatedHabit = habit.copy(
            completedCount = habit.completedCount + 1,
            isCompleted = habit.completedCount + 1 >= habit.targetCount
        )
        
        prefsManager.updateHabit(updatedHabit)
        loadHabits()
        
        val message = if (updatedHabit.isFullyCompleted()) {
            "Great! You completed '${habit.name}' for today!"
        } else {
            "${updatedHabit.completedCount}/${updatedHabit.targetCount} - Keep it up!"
        }
        
        Toast.makeText(requireContext(), message, Toast.LENGTH_SHORT).show()
    }
    
    /**
     * Deletes a habit
     */
    private fun deleteHabit(habit: Habit) {
        prefsManager.deleteHabit(habit.id)
        loadHabits()
        Toast.makeText(requireContext(), "Habit deleted", Toast.LENGTH_SHORT).show()
    }
    
    /**
     * Creates a new habit from dialog input
     */
    private fun createHabitFromDialog(dialogView: View) {
        val name = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_habit_name)?.text?.toString()?.trim() ?: ""
        val description = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_habit_description)?.text?.toString()?.trim() ?: ""
        val targetCount = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_target_count)?.text?.toString()?.toIntOrNull() ?: 1
        val category = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_category)?.text?.toString()?.trim() ?: "General"
        
        if (name.isEmpty()) {
            Toast.makeText(requireContext(), "Please enter a habit name", Toast.LENGTH_SHORT).show()
            return
        }
        
        val newHabit = Habit(
            name = name,
            description = description,
            targetCount = targetCount,
            category = category
        )
        
        prefsManager.addHabit(newHabit)
        loadHabits()
        Toast.makeText(requireContext(), "Habit added!", Toast.LENGTH_SHORT).show()
    }
    
    /**
     * Updates an existing habit from dialog input
     */
    private fun updateHabitFromDialog(habit: Habit, dialogView: View) {
        val name = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_habit_name)?.text?.toString()?.trim() ?: ""
        val description = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_habit_description)?.text?.toString()?.trim() ?: ""
        val targetCount = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_target_count)?.text?.toString()?.toIntOrNull() ?: 1
        val category = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_category)?.text?.toString()?.trim() ?: "General"
        
        if (name.isEmpty()) {
            Toast.makeText(requireContext(), "Please enter a habit name", Toast.LENGTH_SHORT).show()
            return
        }
        
        val updatedHabit = habit.copy(
            name = name,
            description = description,
            targetCount = targetCount,
            category = category
        )
        
        prefsManager.updateHabit(updatedHabit)
        loadHabits()
        Toast.makeText(requireContext(), "Habit updated!", Toast.LENGTH_SHORT).show()
    }
    
    /**
     * Populates dialog fields with existing habit data
     */
    private fun populateHabitDialog(dialogView: View, habit: Habit) {
        dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_habit_name)?.setText(habit.name)
        dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_habit_description)?.setText(habit.description)
        dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_target_count)?.setText(habit.targetCount.toString())
        dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_category)?.setText(habit.category)
    }
    
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
