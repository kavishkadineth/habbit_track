package com.example.labexam03new.adapters

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.labexam03new.databinding.ItemEmojiBinding

/**
 * RecyclerView Adapter for emoji selection
 * Features:
 * - Display available mood emojis
 * - Handle emoji selection with visual feedback
 * - Highlight selected emoji
 */
class EmojiAdapter(
    private val emojis: List<String>,
    private val onEmojiClick: (String) -> Unit
) : RecyclerView.Adapter<EmojiAdapter.EmojiViewHolder>() {
    
    private var selectedEmoji: String = ""
    
    /**
     * ViewHolder for emoji items
     */
    class EmojiViewHolder(val binding: ItemEmojiBinding) : RecyclerView.ViewHolder(binding.root)
    
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EmojiViewHolder {
        val binding = ItemEmojiBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return EmojiViewHolder(binding)
    }
    
    override fun onBindViewHolder(holder: EmojiViewHolder, position: Int) {
        val emoji = emojis[position]
        
        holder.binding.apply {
            tvEmoji.text = emoji
            
            // Highlight selected emoji
            if (emoji == selectedEmoji) {
                root.setCardBackgroundColor(root.context.getColor(com.example.labexam03new.R.color.wellness_accent))
                root.elevation = 8f
            } else {
                root.setCardBackgroundColor(root.context.getColor(com.example.labexam03new.R.color.surface))
                root.elevation = 2f
            }
            
            // Set click listener
            root.setOnClickListener {
                onEmojiClick(emoji)
            }
        }
    }
    
    override fun getItemCount(): Int = emojis.size
    
    /**
     * Sets the selected emoji and updates UI
     */
    fun setSelectedEmoji(emoji: String) {
        selectedEmoji = emoji
        notifyDataSetChanged()
    }
}
