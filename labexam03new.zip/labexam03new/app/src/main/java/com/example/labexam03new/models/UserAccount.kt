package com.example.labexam03new.models

/**
 * Data class representing a user account for authentication
 * @param username User's username
 * @param password User's password (hashed)
 * @param email User's email address
 * @param isLoggedIn Whether the user is currently logged in
 * @param lastLoginTime Timestamp of last login
 */
data class UserAccount(
    val username: String,
    val password: String,
    val email: String,
    val isLoggedIn: Boolean = false,
    val lastLoginTime: Long = System.currentTimeMillis()
)
